# 구해줘홈즈 5조

## 멤버

- 공진호
- 안려환

## 메인화면

| 제목                | 내용                                                                                                                                                         |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 메인페이지 html     | [index.html](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/WebContent/index.html)               |
| 메인 js             | [assets/js/my.js](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/WebContent/assets/js/my.js) |

- Usecase diagram
  <img src="https://github.com/Ryeohwan/Ryeoython/blob/main/img/usecase.PNG?raw=true">

- 메인 화면  
  <img src="https://user-images.githubusercontent.com/62232531/188873885-4382ec3e-ab1b-42dd-b698-61d5dee6f40e.png">


## 구현화면

| 구현 내용       | code                                                                                                                                                       |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| servlet  | [src/controller/DispatcherServlet.java](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/src/controller/DispatcherServlet.java) |
| dao  | [src/dao/MemberDao.java](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/src/dao/MemberDao.java) |
| dto  | [src/dto/Member.java](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/src/dto/Member.java) |
| methods  | [src/service/MemberService.java](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/src/service/MemberService.java) |
| main html (메인) | [index.html](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/WebContent/index.html) |
| signup html (로그인, 회원가입 화면)  | [signup.html](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/WebContent/signup.html) |
| member html (정보 수정 화면) | [member.html](https://lab.ssafy.com/s08/a19/07_whereismyhomes_back/pair05_ahnryeohwan_kongjinho/-/blob/main/final_project_0925/WebContent/member.html) |

- 로그인/로그아웃 기능 

<img src="https://github.com/Ryeohwan/Ryeoython/blob/main/img/login_out.gif?raw=true">

- 회원가입 기능 

<img src="https://github.com/Ryeohwan/Ryeoython/blob/main/img/join.gif?raw=true">

- 회원 정보 조회 및 수정 기능  (탈퇴까지)

<img src="https://github.com/Ryeohwan/Ryeoython/blob/main/img/update.gif?raw=true">

- 회원 정보 중복검사

<img src="https://user-images.githubusercontent.com/62232531/192135798-63b8ed84-b79d-4d66-a64f-87f3fcd76747.gif">
