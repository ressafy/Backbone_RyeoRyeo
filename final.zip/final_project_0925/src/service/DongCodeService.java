package service;

import dto.DongCode;

public class DongCodeService {
	DongCodeDao dongcodeDao;
	private static  DongCodeService instance;
	private DongCodeService() {
		dongcodeDao = DongCodeDao.getInstance();
	}
	
	public static DongCodeService getInstance() {
		if(instance == null) instance = new DongCodeService();
		return instance;
	}
	
	//public method 일단 보류
}
